load('Sumo')
setExtensionUnloadMode('Sumo', 'manual')